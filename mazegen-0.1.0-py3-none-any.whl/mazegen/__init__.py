__version__ = "1.0.0"

__author__ = "Oleksandr Bachurin and Co"

__all__ = ["CMazeParams", "MazeGenerator"]

from .MazeGenerator import CMazeParams, MazeGenerator
